xor1 = [86,65,83,85,76,111,6,15,6,0,1]
xor2 = [53,55,50,52,60,52,50,51,50,50,50]
contrast = [52,60,52,50,51]
phoneNum = ""
flag = ""
for i in range(0,5):
    contrast[i] ^= 4
    phoneNum += chr(contrast[i])
print phoneNum

for j in range(0,11):
    flag += chr(xor1[j] ^ xor2[j] ^ 4)

print flag

# 08067
# greet_08067

import string


enc_flag = [0x1E, 0x15, 0x2, 0x10, 0x0D, 0x48, 0x48, 0x6F, 0xDD, 0xDD, 0x48, 0x64, 0x63, 0xD7, 0x2E, 0x2C, 0xFE, 0x6A, 0x6D, 0x2A, 0xF2, 0x6F, 0x9A, 0x4D, 0x8B, 0x4B, 0xCF, 0xBF, 0x4F, 0x47, 0x4E, 0x13, 0x10, 0x43, 0x0B]
flag = ""

def enc1(word, i):
        word = ord(word) ^ 0x76 ^ 0xAD
        temp1 = (word & 0xAA) >> 1
        temp2 = 2 * word & 0xAA
        word = temp1 | temp2
        return word

def enc2(word, i):        
        word = ord(word) ^ 0x76 ^ 0xBE
        temp1 = (word & 0xCC) >> 2
        temp2 = 4 * word & 0xCC
        word = temp1 | temp2
        return word


def enc3(word,i):
        word = ord(word) ^ 0x76 ^ 0xEF
        temp1 = (word & 0xF0) >> 4
        temp2 = 16 * word & 0xF0
        word = temp1 | temp2
        return word 

for i in range(0,7):
    print chr(enc_flag[i] ^ 0x76)
    flag += chr(enc_flag[i] ^ 0x76)

for i in range(0,7):
    for word1 in string.printable:
        res1 = enc1(word1, i)
        if(res1 == enc_flag[7+i]):
            print chr(ord(word1))
            flag += chr(ord(word1))

for i in range(0,7):
    for word1 in string.printable:
        res1 = enc2(word1, i)
        if(res1 == enc_flag[14+i]):
            print chr(ord(word1))
            flag +=  chr(ord(word1))

for i in range(0,7):
    for word1 in string.printable:
        res1 = enc3(word1, i)
        if(res1 == enc_flag[21+i]):
            print chr(ord(word1))
            flag += chr(ord(word1))

for i in range(0,7):
    print chr(enc_flag[28+i] ^ 0x76)
    flag += chr(enc_flag[28+i] ^ 0x76)

print flag

# M.KATSURAGI
# hctf{>>D55_CH0CK3R_B0o0M!-eb918ef5}





